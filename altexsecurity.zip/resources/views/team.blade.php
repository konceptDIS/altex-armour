@extends('layout')

@section('content')
<!-- start team-section -->
<section class="team-section section-padding">
            <div class="content-area">
                <div class="first-row clearfix">
                    <div class="grid"></div>
                    <div class="grid info-grid">
                        <div class="section-title">
                            <span>#Our Team</span>
                            <h2></h2>
                        </div>
                        <div class="team-details">
                            <p></p>
                            
                        </div>
                    </div>
                    <div class="grid">
                        <div class="img-holder">
                            <img src="assets/images/team/img-1.jpg" alt>
                        </div>
                        <div class="member-info">
                            <h4><a href="#">Michel jhon</a></h4>
                            <p>Dedicated volunteer</p>
                            <ul>
                                <li><a href="#"><i class="ti-facebook"></i></a></li>
                                <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                                <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                <li><a href="#"><i class="ti-pinterest"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="grid">
                        <div class="img-holder">
                            <img src="assets/images/team/img-2.jpg" alt>
                        </div>
                        <div class="member-info">
                            <h4><a href="#">Michel jhon</a></h4>
                            <p>Dedicated volunteer</p>
                            <ul>
                                <li><a href="#"><i class="ti-facebook"></i></a></li>
                                <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                                <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                <li><a href="#"><i class="ti-pinterest"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="sec-row clearfix">
                    <div class="grid">
                        <div class="img-holder">
                            <img src="assets/images/team/img-3.jpg" alt>
                        </div>
                        <div class="member-info">
                            <h4><a href="#">Michel jhon</a></h4>
                            <p>Dedicated volunteer</p>
                            <ul>
                                <li><a href="#"><i class="ti-facebook"></i></a></li>
                                <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                                <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                <li><a href="#"><i class="ti-pinterest"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="grid">
                        <div class="img-holder">
                            <img src="assets/images/team/img-4.jpg" alt>
                        </div>
                        <div class="member-info">
                            <h4><a href="#">Michel jhon</a></h4>
                            <p>Dedicated volunteer</p>
                            <ul>
                                <li><a href="#"><i class="ti-facebook"></i></a></li>
                                <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                                <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                <li><a href="#"><i class="ti-pinterest"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="grid">
                        <div class="img-holder">
                            <img src="assets/images/team/img-5.jpg" alt>
                        </div>
                        <div class="member-info">
                            <h4><a href="#">Michel jhon</a></h4>
                            <p>Dedicated volunteer</p>
                            <ul>
                                <li><a href="#"><i class="ti-facebook"></i></a></li>
                                <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                                <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                <li><a href="#"><i class="ti-pinterest"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="grid">
                        <div class="img-holder">
                            <img src="assets/images/team/img-6.jpg" alt>
                        </div>
                        <div class="member-info">
                            <h4><a href="#">Michel jhon</a></h4>
                            <p>Dedicated volunteer</p>
                            <ul>
                                <li><a href="#"><i class="ti-facebook"></i></a></li>
                                <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                                <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                <li><a href="#"><i class="ti-pinterest"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> <!-- end content-area -->
        </section>
        <!-- end team-section -->
         <!-- start site-footer -->
        <footer class="site-footer">
            <div class="upper-footer">
                <div class="container">
                    <div class="row">
                        <div class="col col-lg-3 col-md-3 col-sm-6">
                            <div class="widget about-widget">
                                <div class="widget-title">
                                    <h3>
                                        copyright@2024 Altex Security
                                    </h3>
                                </div>
                               
                                <!-- <div class="social-icons">
                                    <ul>
                                        <li><a href="#"><i class="ti-facebook"></i></a></li>
                                        <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                                        <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                        <li><a href="#"><i class="ti-pinterest"></i></a></li>
                                    </ul>
                                </div> -->
                            </div>
                        </div>
                        <div class="col col-lg-3 col-md-3 col-sm-6">
                            <div class="widget contact-widget service-link-widget">
                                <div class="widget-title">
                                    <h3>Privacy & Policy</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-3 col-md-3 col-sm-6">
                            <div class="widget link-widget">
                                <div class="widget-title">
                                    <h3>Quick Links</h3>
                                </div>
                                <!-- <ul>
                                    <li><a href="#">About us</a></li>
                                    <li><a href="#">Our services</a></li>
                                    <li><a href="#">Contact us</a></li>
                                    <li><a href="#">Meet team</a></li>
                                </ul>
                                <ul>
                                    <li><a href="#">Privacy Policy</a></li>
                                    <li><a href="#">Testimonials</a></li>
                                    <li><a href="#">News</a></li>
                                    <li><a href="#">FAQ</a></li>
                                </ul> -->
                            </div>
                        </div>
                        <div class="col col-lg-3 col-md-3 col-sm-6">
                              <div class="widget about-widget">
                                <div class="social-icons">
                                    <ul>
                                        <li><a href="https://www.facebook.com/profile.php?id=100069645893237&mibextid=ZbWKwL"><i class="ti-facebook"></i></a></li>
                                        <li><a href=" https://www.tiktok.com/@altex.security?_t=8nZwgcLVFVm&_r=1"><i class="fa-brands fa-tiktok"></i></a></li>
                                        <li><a href="https://www.linkedin.com/company/altex-security/"><i class="ti-linkedin"></i></a></li>
                                        <li><a href="https://www.instagram.com/altexsecurity?igsh=NWt1emFzN2dhM2Jh&utm_source=qr"><i class="ti-instagram"></i></a></li>
                                    </ul>
                                </div> 
                                </div>
                            
                        </div>
                    </div>
                </div> <!-- end container -->
            </div>
            <!-- <div class="lower-footer">
                <div class="container">
                    <div class="row">
                        <div class="separator"></div>
                        <div class="col col-xs-12">
                            <p class="copyright">Copyright &copy; 2020 Proffer. All rights reserved</p>
                            <div class="extra-link">
                                <ul>
                                    <li><a href="#">Privace & Policy</a></li>
                                    <li><a href="#">terms and conditions</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
        </footer>
        <!-- end site-footer -->
@endsection